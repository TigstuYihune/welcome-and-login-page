**Team Coral**
We used the web form template and customized the welcome page for our carbon footprint tracker application. We also added a link-
to a login page withe username, and textbox for a username as well as password and text box for password.


You can launch default.aspx to open the welcome page.
