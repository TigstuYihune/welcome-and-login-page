﻿using System.Web.UI;

namespace Carbon_Footprint_Tracker_Application.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}